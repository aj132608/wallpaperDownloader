from setuptools import setup

with open("README.md", 'r') as f:
    long_description = f.read()

setup(
    name="wallpaperDownloader",
    version="1.0",
    author="Alex Jirovsky",
    install_requires=['pyunsplash', 'requests'],
    long_description=long_description
)
